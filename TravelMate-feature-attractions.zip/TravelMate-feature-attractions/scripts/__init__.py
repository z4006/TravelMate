"""TravelMate 景点脚本。"""
