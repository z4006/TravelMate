"""统一 API 响应格式。"""

from __future__ import annotations

from typing import Any

from flask import jsonify


def api_response(success: bool, message: str, data: Any, status: int = 200):
    """返回统一的 JSON 响应结构。"""
    response = jsonify({"success": success, "message": message, "data": data})
    response.status_code = status
    return response
