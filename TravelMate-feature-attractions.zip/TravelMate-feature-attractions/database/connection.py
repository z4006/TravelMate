"""数据库连接和事务管理。"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Iterator

from flask import current_app, g


def utc_now() -> str:
    """返回 UTC 时间的 ISO-8601 字符串。"""
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "+00:00")


def _get_database_path() -> str:
    if not hasattr(current_app, "config"):
        raise RuntimeError("数据库连接必须在 Flask 应用上下文中使用。")
    return current_app.config["DATABASE"]


def get_db() -> sqlite3.Connection:
    """返回当前请求上下文中的数据库连接。"""
    if "db" not in g:
        connection = sqlite3.connect(_get_database_path())
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        g.db = connection
    return g.db


def close_db(_: object | None = None) -> None:
    """关闭当前请求上下文中的数据库连接。"""
    database = g.pop("db", None)
    if database is not None:
        database.close()


@contextmanager
def db_transaction() -> Iterator[sqlite3.Connection]:
    """提供一个事务上下文，自动提交或回滚。"""
    database = get_db()
    try:
        yield database
        database.commit()
    except Exception:
        database.rollback()
        raise
