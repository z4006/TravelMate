"""TravelMate 景点数据访问。"""
